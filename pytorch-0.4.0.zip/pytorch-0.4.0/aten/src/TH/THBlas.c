#include "THBlas.h"

#include "generic/THBlas.c"
#include "THGenerateAllTypes.h"
