#include "THLapack.h"

#include "generic/THLapack.cpp"
#include "THGenerateFloatTypes.h"
