#ifndef THCS_INC
#define THCS_INC

#include <THC/THCGeneral.h>
#include "THCSTensor.h"

#endif
